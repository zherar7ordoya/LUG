﻿
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1063:ImplementIDisposableCorrectly", Scope = "type", Target = "Microsoft.Samples.NLayerApp.Infrastructure.Data.MainBoundedContext.UnitOfWork.MainBCUnitOfWork")]
