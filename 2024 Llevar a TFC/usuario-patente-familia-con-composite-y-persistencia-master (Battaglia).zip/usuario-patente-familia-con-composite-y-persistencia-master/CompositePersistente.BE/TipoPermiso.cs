﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompositePersistente.BE
{
    public enum TipoPermiso
    {
        PuedeHacerA,
        PuedeHacerB,
        PuedeHacerC,
        PuedeHacerD,
        PuedeHacerE,
        PuedeHacerF,
        PuedeHacerG,
    }

    
   
}
