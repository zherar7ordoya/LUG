﻿namespace EscritorioClasico.Usuarios
{
    partial class UsuarioForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.IngresoGroupBox = new System.Windows.Forms.GroupBox();
            this.IngresoContraseñaTextBox = new System.Windows.Forms.TextBox();
            this.IngresoContraseñaLabel = new System.Windows.Forms.Label();
            this.IngresoUsuarioTextBox = new System.Windows.Forms.TextBox();
            this.IngresoUsuarioLabel = new System.Windows.Forms.Label();
            this.RegistroGroupBox = new System.Windows.Forms.GroupBox();
            this.RegistroContraseñaTextBox = new System.Windows.Forms.TextBox();
            this.RegistroContraseñaLabel = new System.Windows.Forms.Label();
            this.RegistroUsuarioTextBox = new System.Windows.Forms.TextBox();
            this.RegistroUsuarioLabel = new System.Windows.Forms.Label();
            this.IngresoGroupBox.SuspendLayout();
            this.RegistroGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // IngresoGroupBox
            // 
            this.IngresoGroupBox.Controls.Add(this.IngresoContraseñaTextBox);
            this.IngresoGroupBox.Controls.Add(this.IngresoContraseñaLabel);
            this.IngresoGroupBox.Controls.Add(this.IngresoUsuarioTextBox);
            this.IngresoGroupBox.Controls.Add(this.IngresoUsuarioLabel);
            this.IngresoGroupBox.Location = new System.Drawing.Point(300, 100);
            this.IngresoGroupBox.Name = "IngresoGroupBox";
            this.IngresoGroupBox.Size = new System.Drawing.Size(200, 250);
            this.IngresoGroupBox.TabIndex = 0;
            this.IngresoGroupBox.TabStop = false;
            this.IngresoGroupBox.Text = "Ingreso";
            // 
            // IngresoContraseñaTextBox
            // 
            this.IngresoContraseñaTextBox.Enabled = false;
            this.IngresoContraseñaTextBox.Location = new System.Drawing.Point(28, 178);
            this.IngresoContraseñaTextBox.Name = "IngresoContraseñaTextBox";
            this.IngresoContraseñaTextBox.Size = new System.Drawing.Size(147, 20);
            this.IngresoContraseñaTextBox.TabIndex = 4;
            // 
            // IngresoContraseñaLabel
            // 
            this.IngresoContraseñaLabel.Enabled = false;
            this.IngresoContraseñaLabel.Location = new System.Drawing.Point(25, 150);
            this.IngresoContraseñaLabel.Name = "IngresoContraseñaLabel";
            this.IngresoContraseñaLabel.Size = new System.Drawing.Size(150, 25);
            this.IngresoContraseñaLabel.TabIndex = 3;
            this.IngresoContraseñaLabel.Text = "Contraseña";
            this.IngresoContraseñaLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // IngresoUsuarioTextBox
            // 
            this.IngresoUsuarioTextBox.Enabled = false;
            this.IngresoUsuarioTextBox.Location = new System.Drawing.Point(28, 78);
            this.IngresoUsuarioTextBox.Name = "IngresoUsuarioTextBox";
            this.IngresoUsuarioTextBox.Size = new System.Drawing.Size(147, 20);
            this.IngresoUsuarioTextBox.TabIndex = 2;
            // 
            // IngresoUsuarioLabel
            // 
            this.IngresoUsuarioLabel.Enabled = false;
            this.IngresoUsuarioLabel.Location = new System.Drawing.Point(25, 50);
            this.IngresoUsuarioLabel.Name = "IngresoUsuarioLabel";
            this.IngresoUsuarioLabel.Size = new System.Drawing.Size(150, 25);
            this.IngresoUsuarioLabel.TabIndex = 1;
            this.IngresoUsuarioLabel.Text = "Usuario";
            this.IngresoUsuarioLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // RegistroGroupBox
            // 
            this.RegistroGroupBox.Controls.Add(this.RegistroContraseñaTextBox);
            this.RegistroGroupBox.Controls.Add(this.RegistroContraseñaLabel);
            this.RegistroGroupBox.Controls.Add(this.RegistroUsuarioTextBox);
            this.RegistroGroupBox.Controls.Add(this.RegistroUsuarioLabel);
            this.RegistroGroupBox.Location = new System.Drawing.Point(550, 100);
            this.RegistroGroupBox.Name = "RegistroGroupBox";
            this.RegistroGroupBox.Size = new System.Drawing.Size(200, 250);
            this.RegistroGroupBox.TabIndex = 1;
            this.RegistroGroupBox.TabStop = false;
            this.RegistroGroupBox.Text = "Registro";
            // 
            // RegistroContraseñaTextBox
            // 
            this.RegistroContraseñaTextBox.Enabled = false;
            this.RegistroContraseñaTextBox.Location = new System.Drawing.Point(28, 178);
            this.RegistroContraseñaTextBox.Name = "RegistroContraseñaTextBox";
            this.RegistroContraseñaTextBox.Size = new System.Drawing.Size(147, 20);
            this.RegistroContraseñaTextBox.TabIndex = 8;
            // 
            // RegistroContraseñaLabel
            // 
            this.RegistroContraseñaLabel.Enabled = false;
            this.RegistroContraseñaLabel.Location = new System.Drawing.Point(25, 150);
            this.RegistroContraseñaLabel.Name = "RegistroContraseñaLabel";
            this.RegistroContraseñaLabel.Size = new System.Drawing.Size(150, 25);
            this.RegistroContraseñaLabel.TabIndex = 7;
            this.RegistroContraseñaLabel.Text = "Contraseña";
            this.RegistroContraseñaLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // RegistroUsuarioTextBox
            // 
            this.RegistroUsuarioTextBox.Enabled = false;
            this.RegistroUsuarioTextBox.Location = new System.Drawing.Point(28, 78);
            this.RegistroUsuarioTextBox.Name = "RegistroUsuarioTextBox";
            this.RegistroUsuarioTextBox.Size = new System.Drawing.Size(147, 20);
            this.RegistroUsuarioTextBox.TabIndex = 6;
            // 
            // RegistroUsuarioLabel
            // 
            this.RegistroUsuarioLabel.Enabled = false;
            this.RegistroUsuarioLabel.Location = new System.Drawing.Point(25, 50);
            this.RegistroUsuarioLabel.Name = "RegistroUsuarioLabel";
            this.RegistroUsuarioLabel.Size = new System.Drawing.Size(150, 25);
            this.RegistroUsuarioLabel.TabIndex = 5;
            this.RegistroUsuarioLabel.Text = "Usuario";
            this.RegistroUsuarioLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // UsuarioForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1034, 461);
            this.Controls.Add(this.RegistroGroupBox);
            this.Controls.Add(this.IngresoGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "UsuarioForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Usuario";
            this.IngresoGroupBox.ResumeLayout(false);
            this.IngresoGroupBox.PerformLayout();
            this.RegistroGroupBox.ResumeLayout(false);
            this.RegistroGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox IngresoGroupBox;
        private System.Windows.Forms.TextBox IngresoContraseñaTextBox;
        private System.Windows.Forms.Label IngresoContraseñaLabel;
        private System.Windows.Forms.TextBox IngresoUsuarioTextBox;
        private System.Windows.Forms.Label IngresoUsuarioLabel;
        private System.Windows.Forms.GroupBox RegistroGroupBox;
        private System.Windows.Forms.TextBox RegistroContraseñaTextBox;
        private System.Windows.Forms.Label RegistroContraseñaLabel;
        private System.Windows.Forms.TextBox RegistroUsuarioTextBox;
        private System.Windows.Forms.Label RegistroUsuarioLabel;
    }
}