﻿namespace EscritorioClasico.ClienteGiftcard
{
    partial class ClienteGiftcardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.GiftcardAsociadaGroupBox = new System.Windows.Forms.GroupBox();
            this.ProvinciaTextBox = new System.Windows.Forms.TextBox();
            this.DesasociarButton = new System.Windows.Forms.Button();
            this.PaisTextBox = new System.Windows.Forms.TextBox();
            this.RubroTextBox = new System.Windows.Forms.TextBox();
            this.TipoTextBox = new System.Windows.Forms.TextBox();
            this.ProvinciaLabel = new System.Windows.Forms.Label();
            this.PaisLabel = new System.Windows.Forms.Label();
            this.EstadoTextBox = new System.Windows.Forms.TextBox();
            this.EstadoLabel = new System.Windows.Forms.Label();
            this.RubroLabel = new System.Windows.Forms.Label();
            this.DescuentosTextBox = new System.Windows.Forms.TextBox();
            this.DescuentosLabel = new System.Windows.Forms.Label();
            this.SaldoTextBox = new System.Windows.Forms.TextBox();
            this.SaldoLabel = new System.Windows.Forms.Label();
            this.FechaVencimientoTextBox = new System.Windows.Forms.TextBox();
            this.FechaVencimientoLabel = new System.Windows.Forms.Label();
            this.NumeroTextBox = new System.Windows.Forms.TextBox();
            this.NumeroLabel = new System.Windows.Forms.Label();
            this.TipoLabel = new System.Windows.Forms.Label();
            this.CodigoTextBox = new System.Windows.Forms.TextBox();
            this.CodigoLabel = new System.Windows.Forms.Label();
            this.InternacionalesDisponiblesGroupBox = new System.Windows.Forms.GroupBox();
            this.InternacionalesDisponiblesDataGridView = new System.Windows.Forms.DataGridView();
            this.AsociarButton = new System.Windows.Forms.Button();
            this.ClienteGroupBox = new System.Windows.Forms.GroupBox();
            this.ClientesDataGridView = new System.Windows.Forms.DataGridView();
            this.NacionalesDisponiblesGroupBox = new System.Windows.Forms.GroupBox();
            this.NacionalesDisponiblesDataGridView = new System.Windows.Forms.DataGridView();
            this.ImporteImputadoTextBox = new System.Windows.Forms.TextBox();
            this.ImporteImputadoLabel = new System.Windows.Forms.Label();
            this.GiftcardAsociadaGroupBox.SuspendLayout();
            this.InternacionalesDisponiblesGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InternacionalesDisponiblesDataGridView)).BeginInit();
            this.ClienteGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ClientesDataGridView)).BeginInit();
            this.NacionalesDisponiblesGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NacionalesDisponiblesDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // GiftcardAsociadaGroupBox
            // 
            this.GiftcardAsociadaGroupBox.Controls.Add(this.ProvinciaTextBox);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.DesasociarButton);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.PaisTextBox);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.RubroTextBox);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.TipoTextBox);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.ProvinciaLabel);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.PaisLabel);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.EstadoTextBox);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.EstadoLabel);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.RubroLabel);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.DescuentosTextBox);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.DescuentosLabel);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.SaldoTextBox);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.SaldoLabel);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.FechaVencimientoTextBox);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.FechaVencimientoLabel);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.NumeroTextBox);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.NumeroLabel);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.TipoLabel);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.CodigoTextBox);
            this.GiftcardAsociadaGroupBox.Controls.Add(this.CodigoLabel);
            this.GiftcardAsociadaGroupBox.Location = new System.Drawing.Point(343, 12);
            this.GiftcardAsociadaGroupBox.Name = "GiftcardAsociadaGroupBox";
            this.GiftcardAsociadaGroupBox.Size = new System.Drawing.Size(325, 385);
            this.GiftcardAsociadaGroupBox.TabIndex = 0;
            this.GiftcardAsociadaGroupBox.TabStop = false;
            this.GiftcardAsociadaGroupBox.Text = "Gift Card Asociada";
            // 
            // ProvinciaTextBox
            // 
            this.ProvinciaTextBox.Location = new System.Drawing.Point(162, 255);
            this.ProvinciaTextBox.Name = "ProvinciaTextBox";
            this.ProvinciaTextBox.Size = new System.Drawing.Size(150, 20);
            this.ProvinciaTextBox.TabIndex = 57;
            // 
            // DesasociarButton
            // 
            this.DesasociarButton.Location = new System.Drawing.Point(237, 356);
            this.DesasociarButton.Name = "DesasociarButton";
            this.DesasociarButton.Size = new System.Drawing.Size(75, 23);
            this.DesasociarButton.TabIndex = 3;
            this.DesasociarButton.Text = "Desasociar";
            this.DesasociarButton.UseVisualStyleBackColor = true;
            this.DesasociarButton.Click += new System.EventHandler(this.DesasociarButton_Click);
            // 
            // PaisTextBox
            // 
            this.PaisTextBox.Location = new System.Drawing.Point(162, 227);
            this.PaisTextBox.Name = "PaisTextBox";
            this.PaisTextBox.Size = new System.Drawing.Size(150, 20);
            this.PaisTextBox.TabIndex = 56;
            // 
            // RubroTextBox
            // 
            this.RubroTextBox.Location = new System.Drawing.Point(162, 175);
            this.RubroTextBox.Name = "RubroTextBox";
            this.RubroTextBox.Size = new System.Drawing.Size(150, 20);
            this.RubroTextBox.TabIndex = 55;
            // 
            // TipoTextBox
            // 
            this.TipoTextBox.Location = new System.Drawing.Point(162, 45);
            this.TipoTextBox.Name = "TipoTextBox";
            this.TipoTextBox.Size = new System.Drawing.Size(150, 20);
            this.TipoTextBox.TabIndex = 54;
            // 
            // ProvinciaLabel
            // 
            this.ProvinciaLabel.Location = new System.Drawing.Point(6, 250);
            this.ProvinciaLabel.Name = "ProvinciaLabel";
            this.ProvinciaLabel.Size = new System.Drawing.Size(150, 25);
            this.ProvinciaLabel.TabIndex = 53;
            this.ProvinciaLabel.Text = "Provincia";
            this.ProvinciaLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // PaisLabel
            // 
            this.PaisLabel.Location = new System.Drawing.Point(6, 224);
            this.PaisLabel.Name = "PaisLabel";
            this.PaisLabel.Size = new System.Drawing.Size(150, 25);
            this.PaisLabel.TabIndex = 52;
            this.PaisLabel.Text = "País";
            this.PaisLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EstadoTextBox
            // 
            this.EstadoTextBox.Location = new System.Drawing.Point(162, 201);
            this.EstadoTextBox.Name = "EstadoTextBox";
            this.EstadoTextBox.Size = new System.Drawing.Size(150, 20);
            this.EstadoTextBox.TabIndex = 51;
            // 
            // EstadoLabel
            // 
            this.EstadoLabel.Location = new System.Drawing.Point(6, 198);
            this.EstadoLabel.Name = "EstadoLabel";
            this.EstadoLabel.Size = new System.Drawing.Size(150, 25);
            this.EstadoLabel.TabIndex = 50;
            this.EstadoLabel.Text = "Estado";
            this.EstadoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RubroLabel
            // 
            this.RubroLabel.Location = new System.Drawing.Point(6, 172);
            this.RubroLabel.Name = "RubroLabel";
            this.RubroLabel.Size = new System.Drawing.Size(150, 25);
            this.RubroLabel.TabIndex = 49;
            this.RubroLabel.Text = "Rubro";
            this.RubroLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // DescuentosTextBox
            // 
            this.DescuentosTextBox.Location = new System.Drawing.Point(162, 149);
            this.DescuentosTextBox.Name = "DescuentosTextBox";
            this.DescuentosTextBox.Size = new System.Drawing.Size(150, 20);
            this.DescuentosTextBox.TabIndex = 48;
            // 
            // DescuentosLabel
            // 
            this.DescuentosLabel.Location = new System.Drawing.Point(6, 146);
            this.DescuentosLabel.Name = "DescuentosLabel";
            this.DescuentosLabel.Size = new System.Drawing.Size(150, 25);
            this.DescuentosLabel.TabIndex = 47;
            this.DescuentosLabel.Text = "Descuentos";
            this.DescuentosLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // SaldoTextBox
            // 
            this.SaldoTextBox.Location = new System.Drawing.Point(162, 123);
            this.SaldoTextBox.Name = "SaldoTextBox";
            this.SaldoTextBox.Size = new System.Drawing.Size(150, 20);
            this.SaldoTextBox.TabIndex = 46;
            // 
            // SaldoLabel
            // 
            this.SaldoLabel.Location = new System.Drawing.Point(6, 120);
            this.SaldoLabel.Name = "SaldoLabel";
            this.SaldoLabel.Size = new System.Drawing.Size(150, 25);
            this.SaldoLabel.TabIndex = 45;
            this.SaldoLabel.Text = "Saldo";
            this.SaldoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // FechaVencimientoTextBox
            // 
            this.FechaVencimientoTextBox.Location = new System.Drawing.Point(162, 97);
            this.FechaVencimientoTextBox.Name = "FechaVencimientoTextBox";
            this.FechaVencimientoTextBox.Size = new System.Drawing.Size(150, 20);
            this.FechaVencimientoTextBox.TabIndex = 44;
            // 
            // FechaVencimientoLabel
            // 
            this.FechaVencimientoLabel.Location = new System.Drawing.Point(6, 94);
            this.FechaVencimientoLabel.Name = "FechaVencimientoLabel";
            this.FechaVencimientoLabel.Size = new System.Drawing.Size(150, 25);
            this.FechaVencimientoLabel.TabIndex = 43;
            this.FechaVencimientoLabel.Text = "Fecha de Vencimiento";
            this.FechaVencimientoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // NumeroTextBox
            // 
            this.NumeroTextBox.Location = new System.Drawing.Point(162, 71);
            this.NumeroTextBox.Name = "NumeroTextBox";
            this.NumeroTextBox.Size = new System.Drawing.Size(150, 20);
            this.NumeroTextBox.TabIndex = 42;
            // 
            // NumeroLabel
            // 
            this.NumeroLabel.Location = new System.Drawing.Point(6, 68);
            this.NumeroLabel.Name = "NumeroLabel";
            this.NumeroLabel.Size = new System.Drawing.Size(150, 25);
            this.NumeroLabel.TabIndex = 41;
            this.NumeroLabel.Text = "Número";
            this.NumeroLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TipoLabel
            // 
            this.TipoLabel.Location = new System.Drawing.Point(6, 42);
            this.TipoLabel.Name = "TipoLabel";
            this.TipoLabel.Size = new System.Drawing.Size(150, 25);
            this.TipoLabel.TabIndex = 40;
            this.TipoLabel.Text = "Tipo";
            this.TipoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CodigoTextBox
            // 
            this.CodigoTextBox.Location = new System.Drawing.Point(162, 19);
            this.CodigoTextBox.Name = "CodigoTextBox";
            this.CodigoTextBox.Size = new System.Drawing.Size(150, 20);
            this.CodigoTextBox.TabIndex = 39;
            // 
            // CodigoLabel
            // 
            this.CodigoLabel.Location = new System.Drawing.Point(6, 16);
            this.CodigoLabel.Name = "CodigoLabel";
            this.CodigoLabel.Size = new System.Drawing.Size(150, 25);
            this.CodigoLabel.TabIndex = 38;
            this.CodigoLabel.Text = "Código";
            this.CodigoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // InternacionalesDisponiblesGroupBox
            // 
            this.InternacionalesDisponiblesGroupBox.Controls.Add(this.InternacionalesDisponiblesDataGridView);
            this.InternacionalesDisponiblesGroupBox.Location = new System.Drawing.Point(674, 12);
            this.InternacionalesDisponiblesGroupBox.Name = "InternacionalesDisponiblesGroupBox";
            this.InternacionalesDisponiblesGroupBox.Size = new System.Drawing.Size(325, 170);
            this.InternacionalesDisponiblesGroupBox.TabIndex = 1;
            this.InternacionalesDisponiblesGroupBox.TabStop = false;
            this.InternacionalesDisponiblesGroupBox.Text = "Gift Cards Internacionales Disponibles";
            // 
            // InternacionalesDisponiblesDataGridView
            // 
            this.InternacionalesDisponiblesDataGridView.AllowUserToAddRows = false;
            this.InternacionalesDisponiblesDataGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.InternacionalesDisponiblesDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.InternacionalesDisponiblesDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.InternacionalesDisponiblesDataGridView.ColumnHeadersHeight = 25;
            this.InternacionalesDisponiblesDataGridView.Location = new System.Drawing.Point(12, 19);
            this.InternacionalesDisponiblesDataGridView.Name = "InternacionalesDisponiblesDataGridView";
            this.InternacionalesDisponiblesDataGridView.ReadOnly = true;
            this.InternacionalesDisponiblesDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.InternacionalesDisponiblesDataGridView.Size = new System.Drawing.Size(300, 140);
            this.InternacionalesDisponiblesDataGridView.TabIndex = 3;
            this.InternacionalesDisponiblesDataGridView.MouseClick += new System.Windows.Forms.MouseEventHandler(this.InternacionalesDisponiblesDataGridView_MouseClick);
            // 
            // AsociarButton
            // 
            this.AsociarButton.Location = new System.Drawing.Point(911, 368);
            this.AsociarButton.Name = "AsociarButton";
            this.AsociarButton.Size = new System.Drawing.Size(75, 23);
            this.AsociarButton.TabIndex = 4;
            this.AsociarButton.Text = "Asociar";
            this.AsociarButton.UseVisualStyleBackColor = true;
            this.AsociarButton.Click += new System.EventHandler(this.AsociarButton_Click);
            // 
            // ClienteGroupBox
            // 
            this.ClienteGroupBox.Controls.Add(this.ClientesDataGridView);
            this.ClienteGroupBox.Location = new System.Drawing.Point(12, 12);
            this.ClienteGroupBox.Name = "ClienteGroupBox";
            this.ClienteGroupBox.Size = new System.Drawing.Size(325, 385);
            this.ClienteGroupBox.TabIndex = 2;
            this.ClienteGroupBox.TabStop = false;
            this.ClienteGroupBox.Text = "Cliente";
            // 
            // ClientesDataGridView
            // 
            this.ClientesDataGridView.AllowUserToAddRows = false;
            this.ClientesDataGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientesDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.ClientesDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.ClientesDataGridView.ColumnHeadersHeight = 25;
            this.ClientesDataGridView.Location = new System.Drawing.Point(6, 19);
            this.ClientesDataGridView.Name = "ClientesDataGridView";
            this.ClientesDataGridView.ReadOnly = true;
            this.ClientesDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ClientesDataGridView.Size = new System.Drawing.Size(300, 360);
            this.ClientesDataGridView.TabIndex = 2;
            this.ClientesDataGridView.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ClientesDataGridView_MouseClick);
            // 
            // NacionalesDisponiblesGroupBox
            // 
            this.NacionalesDisponiblesGroupBox.Controls.Add(this.NacionalesDisponiblesDataGridView);
            this.NacionalesDisponiblesGroupBox.Location = new System.Drawing.Point(674, 195);
            this.NacionalesDisponiblesGroupBox.Name = "NacionalesDisponiblesGroupBox";
            this.NacionalesDisponiblesGroupBox.Size = new System.Drawing.Size(325, 170);
            this.NacionalesDisponiblesGroupBox.TabIndex = 5;
            this.NacionalesDisponiblesGroupBox.TabStop = false;
            this.NacionalesDisponiblesGroupBox.Text = "Gift Cards Nacionales Disponibles";
            // 
            // NacionalesDisponiblesDataGridView
            // 
            this.NacionalesDisponiblesDataGridView.AllowUserToAddRows = false;
            this.NacionalesDisponiblesDataGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.NacionalesDisponiblesDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.NacionalesDisponiblesDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.NacionalesDisponiblesDataGridView.ColumnHeadersHeight = 25;
            this.NacionalesDisponiblesDataGridView.Location = new System.Drawing.Point(12, 19);
            this.NacionalesDisponiblesDataGridView.Name = "NacionalesDisponiblesDataGridView";
            this.NacionalesDisponiblesDataGridView.ReadOnly = true;
            this.NacionalesDisponiblesDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.NacionalesDisponiblesDataGridView.Size = new System.Drawing.Size(300, 140);
            this.NacionalesDisponiblesDataGridView.TabIndex = 3;
            this.NacionalesDisponiblesDataGridView.MouseClick += new System.Windows.Forms.MouseEventHandler(this.NacionalesDisponiblesDataGridView_MouseClick);
            // 
            // ImporteImputadoTextBox
            // 
            this.ImporteImputadoTextBox.Location = new System.Drawing.Point(805, 371);
            this.ImporteImputadoTextBox.Name = "ImporteImputadoTextBox";
            this.ImporteImputadoTextBox.Size = new System.Drawing.Size(100, 20);
            this.ImporteImputadoTextBox.TabIndex = 48;
            // 
            // ImporteImputadoLabel
            // 
            this.ImporteImputadoLabel.Location = new System.Drawing.Point(699, 368);
            this.ImporteImputadoLabel.Name = "ImporteImputadoLabel";
            this.ImporteImputadoLabel.Size = new System.Drawing.Size(100, 25);
            this.ImporteImputadoLabel.TabIndex = 47;
            this.ImporteImputadoLabel.Text = "Importe a imputar:";
            this.ImporteImputadoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ClienteGiftcardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1009, 550);
            this.Controls.Add(this.ImporteImputadoTextBox);
            this.Controls.Add(this.ImporteImputadoLabel);
            this.Controls.Add(this.AsociarButton);
            this.Controls.Add(this.NacionalesDisponiblesGroupBox);
            this.Controls.Add(this.ClienteGroupBox);
            this.Controls.Add(this.InternacionalesDisponiblesGroupBox);
            this.Controls.Add(this.GiftcardAsociadaGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "ClienteGiftcardForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cliente/Gift Card";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ClienteGiftcardForm_FormClosing);
            this.Load += new System.EventHandler(this.ClienteGiftcardForm_Load);
            this.GiftcardAsociadaGroupBox.ResumeLayout(false);
            this.GiftcardAsociadaGroupBox.PerformLayout();
            this.InternacionalesDisponiblesGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.InternacionalesDisponiblesDataGridView)).EndInit();
            this.ClienteGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ClientesDataGridView)).EndInit();
            this.NacionalesDisponiblesGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.NacionalesDisponiblesDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox GiftcardAsociadaGroupBox;
        private System.Windows.Forms.GroupBox InternacionalesDisponiblesGroupBox;
        private System.Windows.Forms.GroupBox ClienteGroupBox;
        private System.Windows.Forms.DataGridView ClientesDataGridView;
        private System.Windows.Forms.Label ProvinciaLabel;
        private System.Windows.Forms.Label PaisLabel;
        private System.Windows.Forms.TextBox EstadoTextBox;
        private System.Windows.Forms.Label EstadoLabel;
        private System.Windows.Forms.Label RubroLabel;
        private System.Windows.Forms.TextBox DescuentosTextBox;
        private System.Windows.Forms.Label DescuentosLabel;
        private System.Windows.Forms.TextBox SaldoTextBox;
        private System.Windows.Forms.Label SaldoLabel;
        private System.Windows.Forms.TextBox FechaVencimientoTextBox;
        private System.Windows.Forms.Label FechaVencimientoLabel;
        private System.Windows.Forms.TextBox NumeroTextBox;
        private System.Windows.Forms.Label NumeroLabel;
        private System.Windows.Forms.Label TipoLabel;
        private System.Windows.Forms.TextBox CodigoTextBox;
        private System.Windows.Forms.Label CodigoLabel;
        private System.Windows.Forms.DataGridView InternacionalesDisponiblesDataGridView;
        private System.Windows.Forms.Button DesasociarButton;
        private System.Windows.Forms.Button AsociarButton;
        private System.Windows.Forms.TextBox ProvinciaTextBox;
        private System.Windows.Forms.TextBox PaisTextBox;
        private System.Windows.Forms.TextBox RubroTextBox;
        private System.Windows.Forms.TextBox TipoTextBox;
        private System.Windows.Forms.GroupBox NacionalesDisponiblesGroupBox;
        private System.Windows.Forms.DataGridView NacionalesDisponiblesDataGridView;
        private System.Windows.Forms.TextBox ImporteImputadoTextBox;
        private System.Windows.Forms.Label ImporteImputadoLabel;
    }
}