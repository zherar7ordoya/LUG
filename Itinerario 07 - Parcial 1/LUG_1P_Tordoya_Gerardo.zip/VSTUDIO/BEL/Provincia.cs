﻿namespace BEL
{
    public class Provincia : Entidad
    {
        public string Nombre { get; set; }
    }
}
