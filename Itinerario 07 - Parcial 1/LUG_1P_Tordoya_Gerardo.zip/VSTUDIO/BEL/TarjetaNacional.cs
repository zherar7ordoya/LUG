﻿namespace BEL
{
    public class TarjetaNacional : Tarjeta
    {
        public string Provincia { get; set; }
    }
}
