﻿namespace BEL
{
    public class Pais : Entidad
    {
        public string Nombre { get; set; }
    }
}
