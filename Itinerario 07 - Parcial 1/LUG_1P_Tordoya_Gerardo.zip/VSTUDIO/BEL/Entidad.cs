﻿namespace BEL
{
    public class Entidad : ABS.IEntidad
    {
        public int Codigo { get; set; }
    }
}
