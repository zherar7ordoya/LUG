﻿namespace BEL
{
    public class DescuentoCalculado : Entidad
    {
        public int NumeroTarjeta { get; set; }
        public string Tipo { get; set; }
        public double DescuentoOtorgado { get; set; }
    }
}
