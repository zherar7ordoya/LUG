﻿namespace BLL
{
    public abstract class Tarjeta
    {
        public abstract double ObtenerDescuento(double importe);
    }
}
