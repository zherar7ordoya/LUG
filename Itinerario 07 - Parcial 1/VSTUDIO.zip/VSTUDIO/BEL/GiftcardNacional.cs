﻿namespace BEL
{
    public class GiftcardNacional : Giftcard
    {
        public string Provincia { get; set; }
    }
}
