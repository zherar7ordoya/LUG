﻿namespace BLL
{
    public abstract class Giftcard
    {
        public abstract double ObtenerDescuento(double importe);
    }
}
