﻿namespace ABS
{
    public interface IEntidad
    {
        int Codigo { get; set; }
    }
}
