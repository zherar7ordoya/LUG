﻿/**
 * SIN USO.
 */


using System.Windows.Forms;

namespace EscritorioClasico.Usuarios
{
    public partial class UsuarioForm : Form
    {
        public UsuarioForm() => InitializeComponent();
    }
}
