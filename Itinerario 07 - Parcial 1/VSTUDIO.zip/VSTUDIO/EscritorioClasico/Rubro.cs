﻿namespace EscritorioClasico
{
    enum Rubro
    {
        Libre,
        Calzado,
        Electrodomesticos
    }
}
