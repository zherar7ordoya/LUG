USE TPN2a

GO

SELECT AVG(Valor)
FROM Socio
WHERE Socio.Id_Pais = 1