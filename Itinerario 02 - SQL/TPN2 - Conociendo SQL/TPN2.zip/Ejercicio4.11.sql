USE TPN2b

GO

--La consigna pide que "saque el promedio de los jugadores por juego",
--pero, �el promedio de qu�? En la BBDD TPN2a, para realizar este 
--ejercicio, agregu� una columna con un valor arbitrario.
--�As� es como debe cumplimentarse este ejercicio?
