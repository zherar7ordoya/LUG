# Nota

La consigna pide "guardar las consultas realizadas".
Esto fue realizado en el Ejercicio 4.