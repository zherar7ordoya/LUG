USE TPN2a

GO

UPDATE Socio
SET Email = 'xsanchez@mail.net'
WHERE Nombre = 'X'