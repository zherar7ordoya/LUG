USE TPN2b

GO

INSERT INTO Juego
VALUES ('Truco', 'Juego de azar', 2);