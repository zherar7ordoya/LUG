USE TPN2b

GO

SELECT * FROM Bando

GO

SELECT * FROM Juego

GO

SELECT * FROM Jugadores