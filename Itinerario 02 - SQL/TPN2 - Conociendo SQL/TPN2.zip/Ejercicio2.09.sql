USE TPN2a

GO

UPDATE Pais
SET Nombre = 'Francia'
WHERE Pais.Id_Pais = 3;