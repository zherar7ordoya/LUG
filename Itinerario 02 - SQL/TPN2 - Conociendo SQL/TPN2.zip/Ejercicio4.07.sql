USE TPN2b

GO

INSERT INTO Jugadores
VALUES ('Angeles', 'Tordoya', 3);