USE TPN2a

GO

INSERT INTO Socio
VALUES ('Angeles', 'Tordoya', 'atordoya@mail.net', 1, 7);