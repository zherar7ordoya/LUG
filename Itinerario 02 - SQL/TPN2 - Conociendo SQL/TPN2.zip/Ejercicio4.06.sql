USE TPN2b

GO

UPDATE Bando
SET Nombre = 'Ambar'
WHERE Cod_Bando = 3