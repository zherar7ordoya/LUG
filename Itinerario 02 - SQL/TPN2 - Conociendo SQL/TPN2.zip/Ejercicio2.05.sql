USE TPN2a

GO

DELETE FROM Socio
WHERE Socio.Id_Socio = 2