# Respuesta al ejercicio 6

**Agregar m�s informaci�n a una de las tablas y realizar un restore con el backup realizado en el Ejercicio 3. �Qu� sucedi� con la nueva informaci�n ingresada?**

En realidad, el respaldo de esta base de datos se hizo en el Ejercicio 5.

Con respecto a la nueva informaci�n ingresada, la restauraci�n la elimin�.