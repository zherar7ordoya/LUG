USE TPN2b

GO

UPDATE Juego
SET Nombre = 'Ruleta'
WHERE Juego.Cod_Juego = 4;