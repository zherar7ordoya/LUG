USE TPN2b

GO

DELETE FROM Juego
WHERE Cod_Juego = 2