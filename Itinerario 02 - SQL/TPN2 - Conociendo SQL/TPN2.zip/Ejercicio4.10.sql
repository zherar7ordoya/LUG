USE TPN2b

GO

UPDATE Bando
SET Nombre = 'Azul'
WHERE Bando.Nombre = 'Ambar';