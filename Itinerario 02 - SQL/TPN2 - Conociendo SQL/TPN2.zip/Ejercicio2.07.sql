USE TPN2a

GO

INSERT INTO Pais
VALUES ('Mexico');