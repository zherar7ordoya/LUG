﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Historial
    {
        public string ArchivoXML { get; set; }
        public string NombreJuego { get; set; }
        public string Jugador { get; set; }
        public string Estado { get; set; }
        public int Puntos { get; set; }
    }
}
