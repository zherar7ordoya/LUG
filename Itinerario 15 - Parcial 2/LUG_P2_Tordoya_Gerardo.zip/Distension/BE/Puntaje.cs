﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Puntaje
    {
        public string Jugador { get; set; }
        public string Estado { get; set; }
        public int Puntos { get; set; }
    }
}
