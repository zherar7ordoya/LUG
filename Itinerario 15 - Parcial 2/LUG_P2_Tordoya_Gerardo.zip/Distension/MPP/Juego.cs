﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MPP
{
    class Juego : ABSTRACTA.IGestor<BE.Juego>
    {
        public BE.Juego DetallarObjeto(BE.Juego objeto)
        {
            throw new NotImplementedException();
        }

        public bool Guardar(BE.Juego objeto)
        {
            throw new NotImplementedException();
        }

        public List<BE.Juego> RecopilarObjetos()
        {
            throw new NotImplementedException();
        }

        public bool Remover(BE.Juego objeto)
        {
            throw new NotImplementedException();
        }
    }
}
